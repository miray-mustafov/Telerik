class Board:
    def __init__(self):
        self.items = []