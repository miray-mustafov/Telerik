from datetime import datetime

# inject my_now as a dependency
def get_sum_of_numbers(numbers, my_now: datetime):
    my_now_formatted = my_now.strftime("%d/%m/%Y, %H:%M")
    res = sum(numbers)

    return f"{res:.2f}, result created on {my_now_formatted}"

# use this in production
my_now = datetime.now()

# and this for testing purposes
my_now = datetime.fromisoformat("2024-04-10")


print(get_sum_of_numbers([1, 2, 3], my_now))

# ------------------------------------------------------------

from __future__ import annotations

from typing import Callable


class Reply:
    def __init__(self, id, text):
        self.id = id
        self.text = text

    def __str__(self):
        return f"{self.id},{self.text}"


class LogData:

    def __init__(self, logger: Callable):
        self.logger = logger()

    def log(self, data: list):
        self.logger.log(data)

class FileLogger:
    def log(self, data):
        with open("data.csv", "w") as f:
            f.write("\n".join(str(r) for r in data))


class ConsoleLogger:
    def log(self, data):
        for reply in data:
            print(reply)


replies = [Reply(1, "Hello"), Reply(2, "Hi back at you"), Reply(3, "From me too")]
LogData(ConsoleLogger).log(replies)


# ------------------------------------------------------------

class A:
    pass


a = A()
numbers = [a , 2, 3]
print(id(a))
numbers2 = numbers[:]
a1 = numbers2[0]
print(id(a1))





